(function () {
    'use strict';

    angular
        .module('app.detail')
        .controller('DetailController', DetailController);

    DetailController.$inject = ['logger', '$stateParams', '$http', '$filter'];
    /* @ngInject */

    function DetailController(logger, $stateParams, $http, $filter) {

        var vm = this;
        vm.title = 'Detail';
        var postId = $stateParams.postId;

        $http.get('http://192.168.29.92:5000/posts').success(function(data){
            vm.post = $filter('filter')(data, function(d){
                return d.id == postId;
            })[0];
        });
    }
})();
