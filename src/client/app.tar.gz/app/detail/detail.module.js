(function () {
    'use strict';

    angular.module('app.detail', [
        'app.core',
        'app.widgets'
      ]);

})();
