(function () {
    'use strict';

    angular.module('app.home', [
        'app.core',
        'app.widgets'
      ]);

})();
