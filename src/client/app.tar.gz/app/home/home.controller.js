(function () {
    'use strict';

    angular
        .module('app.home')
        .controller('HomeController', HomeController);

    HomeController.$inject = ['logger', '$stateParams', '$http', '$filter'];
    /* @ngInject */
    function HomeController(logger, $stateParams, $http, $filter) {

        var vm = this;
        vm.title = 'Home';
        vm.itemsPerPage = 2;
        if(typeof($stateParams.page) != 'undefined'){
            vm.page = $stateParams.page;
        } else {
            vm.page = 1;
        }
        vm.numb_page = 0;

        $http.get('http://192.168.29.92:5000/posts').success(function(data){
            var numb_item = vm.page * vm.itemsPerPage;
            var i = 0;
            var from = (vm.page - 1)*vm.itemsPerPage;
            vm.posts = $filter('filter')(data, function(d){
                vm.numb_page++;
                if(i < numb_item){
                    i++;
                    if(i > from){
                        return d;
                    }
                }
            });
        });

        vm.pagination = function(){
            var input = [];
            for (var i = 1; i <= Math.ceil(vm.numb_page / vm.itemsPerPage); i += 1) input.push(i);
            return input;
        }
    }
})();
