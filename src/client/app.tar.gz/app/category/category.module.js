(function () {
    'use strict';

    angular.module('app.category', [
        'app.core',
        'app.widgets'
      ]);

})();
