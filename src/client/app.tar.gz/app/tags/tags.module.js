(function () {
    'use strict';

    angular.module('app.tags', [
        'app.core'
      ]);

})();
