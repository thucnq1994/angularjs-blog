(function () {
    'use strict';

    angular.module('app', [
        'app.core',
        'app.widgets',
        'app.home',
        'app.category',
        'app.detail',
        'app.tags',
        'app.layout'
    ]);
})();
